<DOCTYPE HTML>
<html>

<?php
$x=$_POST['theNum'];

if(($x%='2')=='0')
echo "odd";
else
echo "even";

?>
</html>